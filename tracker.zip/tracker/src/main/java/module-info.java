module comp495 {
    requires javafx.controls;
    requires javafx.fxml;

    opens comp495 to javafx.fxml;
    exports comp495;
}
