public  class Note {
 private String title;
 private String body;
 private String date;

 public void Note(){
  title = "";
  body = "";
  date = "";
 }
 public void setTitle(String a){
  title = a;
 }
 public void setBody(String a){
  body = a;
 }
 public void setDate(String  a){
  date = a;
 }
 public String getTitle(){
  return title;
 }
 public String getBody(){
  return body;
 }
}
