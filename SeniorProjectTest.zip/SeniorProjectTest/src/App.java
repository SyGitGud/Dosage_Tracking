import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class App extends JFrame {
    Note note = new Note();
    public String date = "";
    public static void main(String[] args) throws Exception {
        Note note = new Note();
        ArrayList<Note> noteList = new ArrayList<>();
        GridBagLayout gridBag = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JFrame noteFrame = new JFrame();
        noteFrame.setTitle("Notes");
        noteFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        noteFrame.setSize(600, 400);
        JPanel notePanel = new JPanel();
        notePanel.setSize(600, 400);
        notePanel.setLayout(gridBag);
        //
        JTextArea noteTitle = new JTextArea("Enter Title");
        noteTitle.setBackground(new Color(255,255,255));
        noteTitle.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.ipadx = 40;
        gbc.ipady = 15;
        notePanel.add(noteTitle, gbc);
        JTextArea noteBody = new JTextArea();
        noteBody.setBackground(new Color(255,255,255));
        noteBody.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.ipadx = 100;
        gbc.ipady = 100;
        notePanel.add(noteBody, gbc);
        JButton createButton = new JButton("New Note");
        JButton loadButton = new JButton("Load");
        JButton deleteButton = new JButton("Delete");
        JButton saveButton = new JButton("Save");
        notePanel.add(createButton);
        notePanel.add(loadButton);
        notePanel.add(deleteButton);
        notePanel.add(saveButton);
        noteFrame.add(notePanel);

        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                noteBody.setText("Enter Text");
                noteTitle.setText("Enter Title");
                note.setBody("");
                note.setTitle("");
            }
        });
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                String title = JOptionPane.showInputDialog("Enter title");
                for(Note n : noteList){
                    if(n.getTitle() == title){
                        noteBody.setText("Works");
                        noteTitle.setText("works");
                    }
                }
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                String title = JOptionPane.showInputDialog("Enter title");
                for(Note n : noteList){
                    int k = noteList.indexOf(n);
                    if(n.getTitle() == title){
                       noteList.remove(k);
                    }
                }
            }
        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
            note.setBody(noteBody.getText());
            note.setTitle(noteTitle.getText());
            noteList.add(note);
            }
        });
        noteFrame.setVisible(true);
    }
}
